'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Upload, FileSpreadsheet, Download, Users, TrendingUp, TrendingDown, AlertTriangle, Route } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import AdvancedReporting from '@/components/AdvancedReporting'

interface DriverData {
  name: string
  consignments: number
}

interface HandoverData {
  staffInOffice: string[]
  staffInWarehouse: string[]
  topDrivers: DriverData[]
  bottomDrivers: DriverData[]
  issuesWithSort: string
  vacantRouteAllocation: string
  totalDriversOnRoad?: number
  totalShipmentsOnRoad?: number
  totalDrivers?: number
  totalConsignments?: number
}

export default function DailyHandover() {
  const { toast } = useToast()
  const [handoverData, setHandoverData] = useState<HandoverData>({
    staffInOffice: [],
    staffInWarehouse: [],
    topDrivers: [],
    bottomDrivers: [],
    issuesWithSort: '',
    vacantRouteAllocation: '',
    totalDriversOnRoad: 0,
    totalShipmentsOnRoad: 0,
    totalDrivers: 0,
    totalConsignments: 0
  })

  const [newStaff, setNewStaff] = useState({ office: '', warehouse: '' })
  const [newDriver, setNewDriver] = useState({ name: '', consignments: '' })
  const [isUploading, setIsUploading] = useState(false)

  const addStaff = (type: 'office' | 'warehouse') => {
    const value = type === 'office' ? newStaff.office : newStaff.warehouse
    if (!value.trim()) return

    if (type === 'office') {
      setHandoverData(prev => ({
        ...prev,
        staffInOffice: [...prev.staffInOffice, value.trim()]
      }))
      setNewStaff(prev => ({ ...prev, office: '' }))
    } else {
      setHandoverData(prev => ({
        ...prev,
        staffInWarehouse: [...prev.staffInWarehouse, value.trim()]
      }))
      setNewStaff(prev => ({ ...prev, warehouse: '' }))
    }
  }

  const removeStaff = (type: 'office' | 'warehouse', index: number) => {
    if (type === 'office') {
      setHandoverData(prev => ({
        ...prev,
        staffInOffice: prev.staffInOffice.filter((_, i) => i !== index)
      }))
    } else {
      setHandoverData(prev => ({
        ...prev,
        staffInWarehouse: prev.staffInWarehouse.filter((_, i) => i !== index)
      }))
    }
  }

  const addDriver = (type: 'top' | 'bottom') => {
    if (!newDriver.name.trim() || !newDriver.consignments) return

    const driverData = {
      name: newDriver.name.trim(),
      consignments: parseInt(newDriver.consignments)
    }

    if (type === 'top') {
      setHandoverData(prev => ({
        ...prev,
        topDrivers: [...prev.topDrivers, driverData]
      }))
    } else {
      setHandoverData(prev => ({
        ...prev,
        bottomDrivers: [...prev.bottomDrivers, driverData]
      }))
    }

    setNewDriver({ name: '', consignments: '' })
  }

  const removeDriver = (type: 'top' | 'bottom', index: number) => {
    if (type === 'top') {
      setHandoverData(prev => ({
        ...prev,
        topDrivers: prev.topDrivers.filter((_, i) => i !== index)
      }))
    } else {
      setHandoverData(prev => ({
        ...prev,
        bottomDrivers: prev.bottomDrivers.filter((_, i) => i !== index)
      }))
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const response = await fetch('/api/upload-excel', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Failed to upload file')
      }

      const data = await response.json()
      
      setHandoverData(prev => ({
        ...prev,
        totalDrivers: data.totalDrivers,
        totalConsignments: data.totalConsignments,
        totalDriversOnRoad: data.totalDrivers,
        totalShipmentsOnRoad: data.totalConsignments,
        topDrivers: data.topDrivers,
        bottomDrivers: data.bottomDrivers
      }))

      toast({
        title: "Success",
        description: "Excel file analyzed successfully!",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to analyze Excel file",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-center mb-2">Daily Handover System</h1>
        <p className="text-center text-muted-foreground">Track staff, drivers, and daily operations</p>
      </div>

      {/* Summary Cards */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Total Drivers on Road
            </CardTitle>
            <CardDescription>Enter the total number of drivers currently on road</CardDescription>
          </CardHeader>
          <CardContent>
            <Input
              type="number"
              placeholder="Enter total drivers"
              value={handoverData.totalDriversOnRoad || ''}
              onChange={(e) => setHandoverData(prev => ({ 
                ...prev, 
                totalDriversOnRoad: parseInt(e.target.value) || 0 
              }))}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Route className="h-5 w-5" />
              Total Shipments on Road
            </CardTitle>
            <CardDescription>Enter the total number of shipments currently on road</CardDescription>
          </CardHeader>
          <CardContent>
            <Input
              type="number"
              placeholder="Enter total shipments"
              value={handoverData.totalShipmentsOnRoad || ''}
              onChange={(e) => setHandoverData(prev => ({ 
                ...prev, 
                totalShipmentsOnRoad: parseInt(e.target.value) || 0 
              }))}
            />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="manual" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="manual">Manual Entry</TabsTrigger>
          <TabsTrigger value="upload">Excel Upload</TabsTrigger>
        </TabsList>

        <TabsContent value="manual" className="space-y-6">
          {/* Staff Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Staff in Office
                </CardTitle>
                <CardDescription>Add staff members working in the office</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter staff name"
                    value={newStaff.office}
                    onChange={(e) => setNewStaff(prev => ({ ...prev, office: e.target.value }))}
                    onKeyPress={(e) => e.key === 'Enter' && addStaff('office')}
                  />
                  <Button onClick={() => addStaff('office')}>Add</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {handoverData.staffInOffice.map((staff, index) => (
                    <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeStaff('office', index)}>
                      {staff} ×
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Staff in Warehouse
                </CardTitle>
                <CardDescription>Add staff members working in the warehouse</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter staff name"
                    value={newStaff.warehouse}
                    onChange={(e) => setNewStaff(prev => ({ ...prev, warehouse: e.target.value }))}
                    onKeyPress={(e) => e.key === 'Enter' && addStaff('warehouse')}
                  />
                  <Button onClick={() => addStaff('warehouse')}>Add</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {handoverData.staffInWarehouse.map((staff, index) => (
                    <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeStaff('warehouse', index)}>
                      {staff} ×
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Driver Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Top 5 Drivers by Volume
                </CardTitle>
                <CardDescription>Add drivers with highest consignment counts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Driver name"
                    value={newDriver.name}
                    onChange={(e) => setNewDriver(prev => ({ ...prev, name: e.target.value }))}
                  />
                  <Input
                    type="number"
                    placeholder="Consignments"
                    value={newDriver.consignments}
                    onChange={(e) => setNewDriver(prev => ({ ...prev, consignments: e.target.value }))}
                  />
                </div>
                <Button onClick={() => addDriver('top')} className="w-full">Add Top Driver</Button>
                <div className="space-y-2">
                  {handoverData.topDrivers.map((driver, index) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-muted rounded">
                      <span>{driver.name}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="default">{driver.consignments}</Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeDriver('top', index)}
                        >
                          ×
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  Bottom 5 Drivers by Volume
                </CardTitle>
                <CardDescription>Add drivers with lowest consignment counts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Driver name"
                    value={newDriver.name}
                    onChange={(e) => setNewDriver(prev => ({ ...prev, name: e.target.value }))}
                  />
                  <Input
                    type="number"
                    placeholder="Consignments"
                    value={newDriver.consignments}
                    onChange={(e) => setNewDriver(prev => ({ ...prev, consignments: e.target.value }))}
                  />
                </div>
                <Button onClick={() => addDriver('bottom')} className="w-full">Add Bottom Driver</Button>
                <div className="space-y-2">
                  {handoverData.bottomDrivers.map((driver, index) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-muted rounded">
                      <span>{driver.name}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{driver.consignments}</Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeDriver('bottom', index)}
                        >
                          ×
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Issues and Routes */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Issues with Sort
                </CardTitle>
                <CardDescription>Document any sorting issues encountered</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Describe any issues with the sorting process..."
                  value={handoverData.issuesWithSort}
                  onChange={(e) => setHandoverData(prev => ({ ...prev, issuesWithSort: e.target.value }))}
                  rows={4}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Route className="h-5 w-5" />
                  Vacant Route Allocation
                </CardTitle>
                <CardDescription>Document any vacant routes or allocation issues</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Describe any vacant routes or allocation issues..."
                  value={handoverData.vacantRouteAllocation}
                  onChange={(e) => setHandoverData(prev => ({ ...prev, vacantRouteAllocation: e.target.value }))}
                  rows={4}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                Excel Spreadsheet Analysis
              </CardTitle>
              <CardDescription>
                Upload an Excel file to automatically analyze driver data and generate statistics
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <Label htmlFor="file-upload" className="cursor-pointer">
                  <div className="space-y-2">
                    <p className="text-lg font-medium">Upload Excel File</p>
                    <p className="text-sm text-gray-500">
                      Click to browse or drag and drop your Excel file here
                    </p>
                  </div>
                </Label>
                <Input
                  id="file-upload"
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                  disabled={isUploading}
                />
              </div>

              {isUploading && (
                <div className="text-center">
                  <p className="text-sm text-gray-500">Analyzing file...</p>
                </div>
              )}

              {(handoverData.totalDrivers !== undefined && handoverData.totalDrivers > 0) && (
                <div className="grid md:grid-cols-2 gap-4 mt-6">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">{handoverData.totalDrivers}</div>
                        <p className="text-sm text-gray-500">Total Drivers</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600">{handoverData.totalConsignments}</div>
                        <p className="text-sm text-gray-500">Total Consignments</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Advanced Reporting Section */}
      <div className="mt-8">
        <AdvancedReporting handoverData={handoverData} />
      </div>
    </div>
  )
}