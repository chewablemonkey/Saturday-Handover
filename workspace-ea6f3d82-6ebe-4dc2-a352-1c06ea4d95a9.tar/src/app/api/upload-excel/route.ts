import { NextRequest, NextResponse } from 'next/server'
import * as XLSX from 'xlsx'

interface DriverData {
  name: string
  consignments: number
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      )
    }

    // Check if file is Excel format
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      return NextResponse.json(
        { error: 'Please upload a valid Excel file (.xlsx or .xls)' },
        { status: 400 }
      )
    }

    // Convert file to buffer
    const buffer = Buffer.from(await file.arrayBuffer())

    // Parse Excel file
    const workbook = XLSX.read(buffer, { type: 'buffer' })
    const sheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[sheetName]

    // Convert to JSON
    const jsonData = XLSX.utils.sheet_to_json(worksheet)

    // Process the data to extract driver information
    const drivers: DriverData[] = []
    
    // Try to find driver name and consignment columns
    // Common column names for driver names
    const driverNameColumns = [
      'driver', 'driver name', 'name', 'employee', 'employee name',
      'Driver', 'Driver Name', 'Name', 'Employee', 'Employee Name'
    ]
    
    // Common column names for consignments
    const consignmentColumns = [
      'consignments', 'deliveries', 'orders', 'jobs', 'volume',
      'Consignments', 'Deliveries', 'Orders', 'Jobs', 'Volume'
    ]

    // Find the actual column names in the data
    const firstRow = jsonData[0] as any
    const actualColumns = Object.keys(firstRow)
    
    let driverColumn = ''
    let consignmentColumn = ''

    // Find driver column
    for (const col of driverNameColumns) {
      const found = actualColumns.find(actualCol => 
        actualCol.toLowerCase().includes(col.toLowerCase())
      )
      if (found) {
        driverColumn = found
        break
      }
    }

    // Find consignment column
    for (const col of consignmentColumns) {
      const found = actualColumns.find(actualCol => 
        actualCol.toLowerCase().includes(col.toLowerCase())
      )
      if (found) {
        consignmentColumn = found
        break
      }
    }

    // If we couldn't find the columns, try to use the first two columns
    if (!driverColumn && actualColumns.length > 0) {
      driverColumn = actualColumns[0]
    }
    if (!consignmentColumn && actualColumns.length > 1) {
      consignmentColumn = actualColumns[1]
    }

    if (!driverColumn || !consignmentColumn) {
      return NextResponse.json(
        { error: 'Could not find driver name and consignment columns in the Excel file' },
        { status: 400 }
      )
    }

    // Extract driver data
    for (const row of jsonData as any[]) {
      const driverName = row[driverColumn]
      const consignments = parseInt(row[consignmentColumn]) || 0

      if (driverName && consignments >= 0) {
        drivers.push({
          name: String(driverName).trim(),
          consignments
        })
      }
    }

    if (drivers.length === 0) {
      return NextResponse.json(
        { error: 'No valid driver data found in the Excel file' },
        { status: 400 }
      )
    }

    // Calculate statistics
    const totalDrivers = drivers.length
    const totalConsignments = drivers.reduce((sum, driver) => sum + driver.consignments, 0)

    // Sort drivers by consignments (descending)
    const sortedDrivers = [...drivers].sort((a, b) => b.consignments - a.consignments)

    // Get top 5 and bottom 5 drivers
    const topDrivers = sortedDrivers.slice(0, 5)
    const bottomDrivers = [...sortedDrivers].reverse().slice(0, 5)

    return NextResponse.json({
      totalDrivers,
      totalConsignments,
      topDrivers,
      bottomDrivers,
      message: 'File analyzed successfully'
    })

  } catch (error) {
    console.error('Error processing Excel file:', error)
    return NextResponse.json(
      { error: 'Failed to process Excel file' },
      { status: 500 }
    )
  }
}