import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Daily Handover System",
  description: "Professional daily handover system with advanced reporting, Excel integration, and multiple export formats",
  keywords: ["handover", "reporting", "logistics", "drivers", "staff", "Excel", "PDF", "management"],
  authors: [{ name: "Daily Handover Team" }],
  openGraph: {
    title: "Daily Handover System",
    description: "Professional daily handover system with advanced reporting capabilities",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Daily Handover System",
    description: "Professional daily handover system with advanced reporting capabilities",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className="antialiased bg-background text-foreground"
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
