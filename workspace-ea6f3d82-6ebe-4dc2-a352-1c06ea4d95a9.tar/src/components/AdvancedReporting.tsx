'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  Download, 
  FileText, 
  FileSpreadsheet, 
  File, 
  Palette, 
  Settings, 
  Eye,
  Save,
  Plus
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import * as XLSX from 'xlsx'

interface ReportTemplate {
  id: string
  name: string
  description: string
  sections: string[]
  branding: {
    companyName: string
    logoUrl?: string
    primaryColor: string
    secondaryColor: string
  }
}

interface HandoverData {
  staffInOffice: string[]
  staffInWarehouse: string[]
  topDrivers: { name: string; consignments: number }[]
  bottomDrivers: { name: string; consignments: number }[]
  issuesWithSort: string
  vacantRouteAllocation: string
  totalDriversOnRoad?: number
  totalShipmentsOnRoad?: number
  totalDrivers?: number
  totalConsignments?: number
}

interface AdvancedReportingProps {
  handoverData: HandoverData
}

const defaultTemplates: ReportTemplate[] = [
  {
    id: 'standard',
    name: 'Standard Report',
    description: 'Complete daily handover report with all sections',
    sections: ['summary', 'staff', 'drivers', 'issues', 'routes'],
    branding: {
      companyName: 'Your Company',
      primaryColor: '#2563eb',
      secondaryColor: '#64748b'
    }
  },
  {
    id: 'executive',
    name: 'Executive Summary',
    description: 'High-level overview for management',
    sections: ['summary', 'drivers'],
    branding: {
      companyName: 'Your Company',
      primaryColor: '#059669',
      secondaryColor: '#64748b'
    }
  },
  {
    id: 'operations',
    name: 'Operations Detail',
    description: 'Detailed operations and staff information',
    sections: ['summary', 'staff', 'issues', 'routes'],
    branding: {
      companyName: 'Your Company',
      primaryColor: '#dc2626',
      secondaryColor: '#64748b'
    }
  }
]

export default function AdvancedReporting({ handoverData }: AdvancedReportingProps) {
  const { toast } = useToast()
  const [selectedTemplate, setSelectedTemplate] = useState<ReportTemplate>(defaultTemplates[0])
  const [customTemplates, setCustomTemplates] = useState<ReportTemplate[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [showTemplateDialog, setShowTemplateDialog] = useState(false)
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    sections: ['summary', 'staff', 'drivers', 'issues', 'routes'],
    branding: {
      companyName: 'Your Company',
      primaryColor: '#2563eb',
      secondaryColor: '#64748b'
    }
  })

  const generateHTMLReport = (template: ReportTemplate) => {
    const sections = template.sections
    let html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${template.name} - Daily Handover Report</title>
        <style>
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            line-height: 1.6;
            background-color: #f8fafc;
          }
          .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
          }
          .header { 
            background: linear-gradient(135deg, ${template.branding.primaryColor}, ${template.branding.secondaryColor}); 
            color: white;
            padding: 30px;
            text-align: center;
          }
          .header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 700;
          }
          .header .company {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-top: 8px;
          }
          .header .date {
            font-size: 1rem;
            opacity: 0.8;
            margin-top: 4px;
          }
          .section { 
            margin: 0; 
            padding: 25px 30px;
            border-bottom: 1px solid #e2e8f0;
          }
          .section:last-child {
            border-bottom: none;
          }
          .section h2 { 
            color: ${template.branding.primaryColor}; 
            margin-top: 0; 
            margin-bottom: 20px;
            font-size: 1.5rem;
            font-weight: 600;
            border-bottom: 2px solid ${template.branding.primaryColor};
            padding-bottom: 8px;
          }
          .section h3 {
            color: #334155;
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 1.1rem;
            font-weight: 600;
          }
          .staff-list { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 8px; 
            margin-top: 15px; 
          }
          .staff-badge { 
            background: ${template.branding.primaryColor}20; 
            color: ${template.branding.primaryColor};
            padding: 6px 12px; 
            border-radius: 20px; 
            font-size: 14px;
            font-weight: 500;
            border: 1px solid ${template.branding.primaryColor}40;
          }
          .driver-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 15px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
          }
          .driver-table th, .driver-table td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #e2e8f0;
          }
          .driver-table th { 
            background: ${template.branding.primaryColor}10; 
            color: ${template.branding.primaryColor};
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .driver-table tr:hover {
            background: #f8fafc;
          }
          .stats { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px; 
            margin-top: 20px; 
          }
          .stat-item { 
            background: linear-gradient(135deg, ${template.branding.primaryColor}10, ${template.branding.secondaryColor}10); 
            padding: 20px; 
            border-radius: 12px; 
            text-align: center;
            border: 1px solid ${template.branding.primaryColor}20;
          }
          .stat-value { 
            font-size: 2.5rem; 
            font-weight: 700; 
            color: ${template.branding.primaryColor};
            margin-bottom: 5px;
          }
          .stat-label { 
            color: #64748b; 
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .issue-box {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
          }
          .issue-box h4 {
            color: #dc2626;
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 16px;
          }
          .route-box {
            background: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
          }
          .route-box h4 {
            color: #0284c7;
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 16px;
          }
          .empty-state {
            text-align: center;
            color: #64748b;
            font-style: italic;
            padding: 20px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${template.name}</h1>
            <div class="company">${template.branding.companyName}</div>
            <div class="date">Generated on: ${new Date().toLocaleDateString()}</div>
          </div>
    `

    // Add sections based on template
    if (sections.includes('summary')) {
      html += `
        <div class="section">
          <h2>Current Road Summary</h2>
          <div class="stats">
            <div class="stat-item">
              <div class="stat-value">${handoverData.totalDriversOnRoad || 0}</div>
              <div class="stat-label">Drivers on Road</div>
            </div>
            <div class="stat-item">
              <div class="stat-value">${handoverData.totalShipmentsOnRoad || 0}</div>
              <div class="stat-label">Shipments on Road</div>
            </div>
            ${handoverData.totalDrivers ? `
            <div class="stat-item">
              <div class="stat-value">${handoverData.totalDrivers}</div>
              <div class="stat-label">Total Drivers</div>
            </div>
            <div class="stat-item">
              <div class="stat-value">${handoverData.totalConsignments}</div>
              <div class="stat-label">Total Consignments</div>
            </div>
            ` : ''}
          </div>
        </div>
      `
    }

    if (sections.includes('staff')) {
      html += `
        <div class="section">
          <h2>Staff Information</h2>
          <h3>Staff in Office</h3>
          <div class="staff-list">
            ${handoverData.staffInOffice.length > 0 
              ? handoverData.staffInOffice.map(staff => `<span class="staff-badge">${staff}</span>`).join('')
              : '<div class="empty-state">No staff members listed</div>'
            }
          </div>
          <h3>Staff in Warehouse</h3>
          <div class="staff-list">
            ${handoverData.staffInWarehouse.length > 0 
              ? handoverData.staffInWarehouse.map(staff => `<span class="staff-badge">${staff}</span>`).join('')
              : '<div class="empty-state">No staff members listed</div>'
            }
          </div>
        </div>
      `
    }

    if (sections.includes('drivers')) {
      html += `
        <div class="section">
          <h2>Driver Performance</h2>
          <h3>Top 5 Drivers by Volume</h3>
          ${handoverData.topDrivers.length > 0 ? `
            <table class="driver-table">
              <thead>
                <tr>
                  <th>Driver Name</th>
                  <th>Consignments</th>
                </tr>
              </thead>
              <tbody>
                ${handoverData.topDrivers.map(driver => `
                  <tr>
                    <td>${driver.name}</td>
                    <td><strong>${driver.consignments}</strong></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          ` : '<div class="empty-state">No driver performance data available</div>'}
          
          <h3>Bottom 5 Drivers by Volume</h3>
          ${handoverData.bottomDrivers.length > 0 ? `
            <table class="driver-table">
              <thead>
                <tr>
                  <th>Driver Name</th>
                  <th>Consignments</th>
                </tr>
              </thead>
              <tbody>
                ${handoverData.bottomDrivers.map(driver => `
                  <tr>
                    <td>${driver.name}</td>
                    <td><strong>${driver.consignments}</strong></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          ` : '<div class="empty-state">No driver performance data available</div>'}
        </div>
      `
    }

    if (sections.includes('issues')) {
      html += `
        <div class="section">
          <h2>Issues with Sort</h2>
          ${handoverData.issuesWithSort ? `
            <div class="issue-box">
              <h4>Reported Issues</h4>
              <p>${handoverData.issuesWithSort}</p>
            </div>
          ` : '<div class="empty-state">No issues reported</div>'}
        </div>
      `
    }

    if (sections.includes('routes')) {
      html += `
        <div class="section">
          <h2>Vacant Route Allocation</h2>
          ${handoverData.vacantRouteAllocation ? `
            <div class="route-box">
              <h4>Route Status</h4>
              <p>${handoverData.vacantRouteAllocation}</p>
            </div>
          ` : '<div class="empty-state">All routes allocated</div>'}
        </div>
      `
    }

    html += `
        </div>
      </body>
      </html>
    `

    return html
  }

  const downloadHTMLReport = () => {
    const html = generateHTMLReport(selectedTemplate)
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${selectedTemplate.name.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Success",
      description: "HTML report downloaded successfully!",
    })
  }

  const downloadPDFReport = async () => {
    setIsGenerating(true)
    try {
      const html = generateHTMLReport(selectedTemplate)
      
      // Create a temporary div to render HTML
      const tempDiv = document.createElement('div')
      tempDiv.innerHTML = html
      tempDiv.style.position = 'absolute'
      tempDiv.style.left = '-9999px'
      tempDiv.style.width = '800px'
      document.body.appendChild(tempDiv)

      // Convert to canvas
      const canvas = await html2canvas(tempDiv.querySelector('.container') as HTMLElement, {
        scale: 2,
        useCORS: true,
        allowTaint: true
      })

      // Create PDF
      const pdf = new jsPDF('p', 'mm', 'a4')
      const imgData = canvas.toDataURL('image/png')
      
      const pdfWidth = pdf.internal.pageSize.getWidth()
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width
      
      if (pdfHeight > 297) {
        // Multiple pages
        let remainingHeight = canvas.height
        let sourceY = 0
        
        while (remainingHeight > 0) {
          const pageHeight = Math.min(297 * (canvas.width / 210), remainingHeight)
          const pageCanvas = document.createElement('canvas')
          pageCanvas.width = canvas.width
          pageCanvas.height = pageHeight * (canvas.width / 210)
          
          const pageCtx = pageCanvas.getContext('2d')
          if (pageCtx) {
            pageCtx.drawImage(canvas, 0, sourceY, canvas.width, pageHeight * (canvas.width / 210), 0, 0, pageCanvas.width, pageCanvas.height)
          }
          
          const pageImgData = pageCanvas.toDataURL('image/png')
          
          if (sourceY > 0) {
            pdf.addPage()
          }
          
          pdf.addImage(pageImgData, 'PNG', 0, 0, pdfWidth, (pageCanvas.height * pdfWidth) / pageCanvas.width)
          
          sourceY += pageHeight * (canvas.width / 210)
          remainingHeight -= pageHeight * (canvas.width / 210)
        }
      } else {
        // Single page
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight)
      }

      // Clean up
      document.body.removeChild(tempDiv)

      pdf.save(`${selectedTemplate.name.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`)

      toast({
        title: "Success",
        description: "PDF report downloaded successfully!",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF report",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const downloadExcelReport = () => {
    const workbook = XLSX.utils.book_new()
    
    // Summary sheet
    const summaryData = [
      ['Metric', 'Value'],
      ['Total Drivers on Road', handoverData.totalDriversOnRoad || 0],
      ['Total Shipments on Road', handoverData.totalShipmentsOnRoad || 0],
      ['Total Drivers', handoverData.totalDrivers || 0],
      ['Total Consignments', handoverData.totalConsignments || 0],
      ['Report Generated', new Date().toLocaleDateString()],
      ['Template', selectedTemplate.name]
    ]
    const summarySheet = XLSX.utils.aoa_to_sheet(summaryData)
    XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary')

    // Staff sheet
    if (handoverData.staffInOffice.length > 0 || handoverData.staffInWarehouse.length > 0) {
      const staffData = [
        ['Location', 'Staff Name'],
        ...handoverData.staffInOffice.map(staff => ['Office', staff]),
        ...handoverData.staffInWarehouse.map(staff => ['Warehouse', staff])
      ]
      const staffSheet = XLSX.utils.aoa_to_sheet(staffData)
      XLSX.utils.book_append_sheet(workbook, staffSheet, 'Staff')
    }

    // Drivers sheet
    if (handoverData.topDrivers.length > 0 || handoverData.bottomDrivers.length > 0) {
      const driversData = [
        ['Category', 'Driver Name', 'Consignments'],
        ...handoverData.topDrivers.map(driver => ['Top Performer', driver.name, driver.consignments]),
        ...handoverData.bottomDrivers.map(driver => ['Bottom Performer', driver.name, driver.consignments])
      ]
      const driversSheet = XLSX.utils.aoa_to_sheet(driversData)
      XLSX.utils.book_append_sheet(workbook, driversSheet, 'Drivers')
    }

    // Issues sheet
    if (handoverData.issuesWithSort || handoverData.vacantRouteAllocation) {
      const issuesData = [
        ['Category', 'Description'],
        ['Sort Issues', handoverData.issuesWithSort || 'None'],
        ['Route Allocation', handoverData.vacantRouteAllocation || 'All routes allocated']
      ]
      const issuesSheet = XLSX.utils.aoa_to_sheet(issuesData)
      XLSX.utils.book_append_sheet(workbook, issuesSheet, 'Issues & Routes')
    }

    XLSX.writeFile(workbook, `${selectedTemplate.name.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.xlsx`)

    toast({
      title: "Success",
      description: "Excel report downloaded successfully!",
    })
  }

  const downloadCSVReport = () => {
    let csvContent = "Category,Item,Value\n"
    
    // Summary data
    csvContent += `Summary,Total Drivers on Road,${handoverData.totalDriversOnRoad || 0}\n`
    csvContent += `Summary,Total Shipments on Road,${handoverData.totalShipmentsOnRoad || 0}\n`
    csvContent += `Summary,Total Drivers,${handoverData.totalDrivers || 0}\n`
    csvContent += `Summary,Total Consignments,${handoverData.totalConsignments || 0}\n`
    
    // Staff data
    handoverData.staffInOffice.forEach(staff => {
      csvContent += `Staff,Office,${staff}\n`
    })
    handoverData.staffInWarehouse.forEach(staff => {
      csvContent += `Staff,Warehouse,${staff}\n`
    })
    
    // Driver data
    handoverData.topDrivers.forEach(driver => {
      csvContent += `Drivers,Top Performer - ${driver.name},${driver.consignments}\n`
    })
    handoverData.bottomDrivers.forEach(driver => {
      csvContent += `Drivers,Bottom Performer - ${driver.name},${driver.consignments}\n`
    })
    
    // Issues and routes
    if (handoverData.issuesWithSort) {
      csvContent += `Issues,Sort Issues,"${handoverData.issuesWithSort}"\n`
    }
    if (handoverData.vacantRouteAllocation) {
      csvContent += `Routes,Vacant Routes,"${handoverData.vacantRouteAllocation}"\n`
    }

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${selectedTemplate.name.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Success",
      description: "CSV report downloaded successfully!",
    })
  }

  const saveCustomTemplate = () => {
    if (!newTemplate.name.trim()) {
      toast({
        title: "Error",
        description: "Template name is required",
        variant: "destructive",
      })
      return
    }

    const template: ReportTemplate = {
      id: Date.now().toString(),
      name: newTemplate.name,
      description: newTemplate.description,
      sections: newTemplate.sections,
      branding: newTemplate.branding
    }

    setCustomTemplates(prev => [...prev, template])
    setShowTemplateDialog(false)
    setNewTemplate({
      name: '',
      description: '',
      sections: ['summary', 'staff', 'drivers', 'issues', 'routes'],
      branding: {
        companyName: 'Your Company',
        primaryColor: '#2563eb',
        secondaryColor: '#64748b'
      }
    })

    toast({
      title: "Success",
      description: "Custom template saved successfully!",
    })
  }

  const allTemplates = [...defaultTemplates, ...customTemplates]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Advanced Reporting
        </CardTitle>
        <CardDescription>
          Generate professional reports in multiple formats with custom templates and branding
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Template Selection */}
        <div className="space-y-4">
          <Label>Select Report Template</Label>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allTemplates.map(template => (
              <Card 
                key={template.id} 
                className={`cursor-pointer transition-all ${
                  selectedTemplate.id === template.id 
                    ? 'ring-2 ring-blue-500 bg-blue-50' 
                    : 'hover:shadow-md'
                }`}
                onClick={() => setSelectedTemplate(template)}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: template.branding.primaryColor }}
                    />
                    {template.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground mb-2">
                    {template.description}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {template.sections.map(section => (
                      <Badge key={section} variant="outline" className="text-xs">
                        {section}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Export Options */}
        <div className="space-y-4">
          <Label>Export Format</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button 
              onClick={downloadHTMLReport}
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4"
            >
              <FileText className="h-6 w-6" />
              <span className="text-sm">HTML</span>
            </Button>
            
            <Button 
              onClick={downloadPDFReport}
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4"
              disabled={isGenerating}
            >
              <FileText className="h-6 w-6" />
              <span className="text-sm">PDF</span>
            </Button>
            
            <Button 
              onClick={downloadExcelReport}
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4"
            >
              <FileSpreadsheet className="h-6 w-6" />
              <span className="text-sm">Excel</span>
            </Button>
            
            <Button 
              onClick={downloadCSVReport}
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4"
            >
              <File className="h-6 w-6" />
              <span className="text-sm">CSV</span>
            </Button>
          </div>
        </div>

        {/* Template Management */}
        <div className="flex justify-between items-center pt-4 border-t">
          <div className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="text-sm font-medium">Custom Templates</span>
            <Badge variant="secondary">{customTemplates.length}</Badge>
          </div>
          
          <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Create Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Custom Template</DialogTitle>
                <DialogDescription>
                  Design your own report template with custom sections and branding
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="template-name">Template Name</Label>
                    <Input
                      id="template-name"
                      value={newTemplate.name}
                      onChange={(e) => setNewTemplate(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter template name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="template-description">Description</Label>
                    <Input
                      id="template-description"
                      value={newTemplate.description}
                      onChange={(e) => setNewTemplate(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Enter description"
                    />
                  </div>
                </div>

                <div>
                  <Label>Report Sections</Label>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {['summary', 'staff', 'drivers', 'issues', 'routes'].map(section => (
                      <label key={section} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newTemplate.sections.includes(section)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewTemplate(prev => ({
                                ...prev,
                                sections: [...prev.sections, section]
                              }))
                            } else {
                              setNewTemplate(prev => ({
                                ...prev,
                                sections: prev.sections.filter(s => s !== section)
                              }))
                            }
                          }}
                          className="rounded"
                        />
                        <span className="text-sm capitalize">{section}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="company-name">Company Name</Label>
                    <Input
                      id="company-name"
                      value={newTemplate.branding.companyName}
                      onChange={(e) => setNewTemplate(prev => ({
                        ...prev,
                        branding: { ...prev.branding, companyName: e.target.value }
                      }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="primary-color">Primary Color</Label>
                    <Input
                      id="primary-color"
                      type="color"
                      value={newTemplate.branding.primaryColor}
                      onChange={(e) => setNewTemplate(prev => ({
                        ...prev,
                        branding: { ...prev.branding, primaryColor: e.target.value }
                      }))}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="secondary-color">Secondary Color</Label>
                  <Input
                    id="secondary-color"
                    type="color"
                    value={newTemplate.branding.secondaryColor}
                    onChange={(e) => setNewTemplate(prev => ({
                      ...prev,
                      branding: { ...prev.branding, secondaryColor: e.target.value }
                    }))}
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowTemplateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={saveCustomTemplate}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Template
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Template Preview */}
        <div className="pt-4 border-t">
          <div className="flex items-center gap-2 mb-4">
            <Eye className="h-4 w-4" />
            <span className="text-sm font-medium">Template Preview</span>
          </div>
          
          <div className="border rounded-lg p-4 bg-gray-50">
            <div className="text-center mb-4">
              <div 
                className="inline-block px-4 py-2 rounded text-white font-semibold mb-2"
                style={{ backgroundColor: selectedTemplate.branding.primaryColor }}
              >
                {selectedTemplate.name}
              </div>
              <div className="text-sm text-gray-600">
                {selectedTemplate.branding.companyName}
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              {selectedTemplate.sections.includes('summary') && (
                <>
                  <div className="bg-white p-3 rounded border">
                    <div className="font-bold text-lg" style={{ color: selectedTemplate.branding.primaryColor }}>
                      {handoverData.totalDriversOnRoad || 0}
                    </div>
                    <div className="text-xs text-gray-600">Drivers</div>
                  </div>
                  <div className="bg-white p-3 rounded border">
                    <div className="font-bold text-lg" style={{ color: selectedTemplate.branding.primaryColor }}>
                      {handoverData.totalShipmentsOnRoad || 0}
                    </div>
                    <div className="text-xs text-gray-600">Shipments</div>
                  </div>
                </>
              )}
              {selectedTemplate.sections.includes('staff') && (
                <div className="bg-white p-3 rounded border">
                  <div className="font-bold text-lg" style={{ color: selectedTemplate.branding.primaryColor }}>
                    {handoverData.staffInOffice.length + handoverData.staffInWarehouse.length}
                  </div>
                  <div className="text-xs text-gray-600">Staff</div>
                </div>
              )}
              {selectedTemplate.sections.includes('drivers') && (
                <div className="bg-white p-3 rounded border">
                  <div className="font-bold text-lg" style={{ color: selectedTemplate.branding.primaryColor }}>
                    {handoverData.topDrivers.length + handoverData.bottomDrivers.length}
                  </div>
                  <div className="text-xs text-gray-600">Drivers</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}