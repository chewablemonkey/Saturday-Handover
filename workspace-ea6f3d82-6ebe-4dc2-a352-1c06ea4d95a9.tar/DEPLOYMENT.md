# Daily Handover System - Deployment Guide

## Overview
The Daily Handover System is a professional web application for managing daily logistics operations with advanced reporting capabilities.

## Features
- **Staff Management**: Track office and warehouse staff
- **Driver Performance**: Monitor top and bottom performers by volume
- **Excel Integration**: Upload and analyze spreadsheets automatically
- **Advanced Reporting**: Generate reports in HTML, PDF, Excel, and CSV formats
- **Custom Templates**: Create branded report templates
- **Real-time Data**: Manual entry with automatic Excel data synchronization

## Prerequisites
- Node.js 18+ 
- npm or yarn
- Modern web browser

## Installation

### 1. Clone and Setup
```bash
git clone <repository-url>
cd daily-handover-system
npm install
```

### 2. Environment Configuration
Create a `.env.local` file for production:
```env
NODE_ENV=production
PORT=3000
HOSTNAME=0.0.0.0
```

### 3. Build the Application
```bash
npm run build
```

### 4. Start the Production Server
```bash
npm start
```

## Development Setup

### Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:3000`

### Code Quality
```bash
# Run linting
npm run lint

# Type checking
npx tsc --noEmit
```

## Architecture

### Frontend
- **Framework**: Next.js 15 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: React hooks with Zustand

### Backend
- **API Routes**: Next.js API routes
- **File Processing**: xlsx library for Excel handling
- **PDF Generation**: jsPDF with html2canvas
- **Real-time**: Socket.IO integration

### Key Components
- `src/app/page.tsx`: Main application interface
- `src/components/AdvancedReporting.tsx`: Reporting functionality
- `src/app/api/upload-excel/route.ts`: Excel processing API
- `src/app/layout.tsx`: Application layout and metadata

## Deployment Options

### 1. Standalone Server
```bash
npm run build
npm start
```

### 2. Docker Deployment
Create a `Dockerfile`:
```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000
CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t daily-handover .
docker run -p 3000:3000 daily-handover
```

### 3. Platform Deployment
- **Vercel**: Connect repository and deploy
- **Netlify**: Build command `npm run build`, publish directory `.next`
- **AWS Amplify**: Connect repository with build settings
- **Railway**: Deploy with one click

## Environment Variables

### Required for Production
```env
NODE_ENV=production
PORT=3000
HOSTNAME=0.0.0.0
```

### Optional
```env
# Database (if using Prisma)
DATABASE_URL="file:./dev.db"

# External APIs (if needed)
API_KEY=your-api-key
```

## Security Considerations

### File Upload Security
- File type validation (.xlsx, .xls only)
- File size limits
- Input sanitization
- Error handling without exposing system details

### API Security
- Rate limiting considerations
- Input validation
- CORS configuration
- Error handling

### Data Protection
- No sensitive data in logs
- Secure file handling
- Proper error messages

## Performance Optimization

### Build Optimization
- Tree shaking enabled
- Code splitting automatic
- Image optimization with Sharp
- Bundle analysis available

### Runtime Optimization
- Static site generation where possible
- Efficient data fetching
- Optimized images and assets
- Caching strategies

## Monitoring and Logging

### Application Logging
```bash
# Development logs (with tee)
npm run dev 2>&1 | tee dev.log

# Production logs
npm start 2>&1 | tee server.log
```

### Health Checks
- Health endpoint: `/api/health`
- Returns: `{ message: "Good!" }`
- Status: 200 OK

## Troubleshooting

### Common Issues

#### Build Failures
```bash
# Clear Next.js cache
rm -rf .next
npm run build

# Check TypeScript errors
npx tsc --noEmit

# Check linting issues
npm run lint
```

#### Font Loading Issues
The application uses system fonts to avoid Google Fonts dependency issues:
- Sans-serif: System font stack
- Monospace: System monospace stack

#### File Upload Issues
- Ensure file types are .xlsx or .xls
- Check file size limits
- Verify API endpoint accessibility

### Performance Issues
- Monitor memory usage during PDF generation
- Consider implementing rate limiting for file uploads
- Optimize large Excel file processing

## Backup and Recovery

### Data Backup
- User data is client-side only (no database persistence)
- Excel files are processed in memory only
- No persistent storage requirements

### Recovery
- Restart application to clear all data
- Re-upload Excel files if needed
- Manual data re-entry required

## Scaling Considerations

### Horizontal Scaling
- Stateless application design
- Session data stored client-side
- File processing in memory
- Easy to load balance

### Vertical Scaling
- Memory requirements for PDF generation
- CPU requirements for Excel processing
- Consider file size limits for scaling

## Maintenance

### Updates
```bash
# Update dependencies
npm update

# Security updates
npm audit fix
```

### Monitoring
- Monitor server resources
- Track error rates
- Monitor file upload success rates
- Performance metrics

## Support

### Issues
- Check browser console for errors
- Review server logs
- Verify file formats and sizes
- Test with sample data

### Feature Requests
- Submit through issue tracker
- Include use case details
- Provide sample data if applicable

## License
This project is licensed under the MIT License.