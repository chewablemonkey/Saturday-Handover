# Daily Handover System - Deployment Instructions

## Quick Start

### Option 1: Direct Node.js (Recommended)
```bash
# Install dependencies
npm install

# Start the application
npm start

# The application will be available at http://localhost:3000
```

### Option 2: With Custom Port
```bash
# Start on port 3001
PORT=3001 npm start
```

### Option 3: Docker Deployment
```bash
# Build Docker image
docker build -t daily-handover .

# Run container
docker run -p 3000:3000 daily-handover
```

## Features

- ✅ **Staff Management**: Track office and warehouse staff
- ✅ **Driver Performance**: Monitor top/bottom performers by volume
- ✅ **Excel Integration**: Upload and analyze spreadsheets (demo mode)
- ✅ **Real-time Summary**: Total drivers and shipments on road
- ✅ **Issue Tracking**: Document sorting issues and route allocations
- ✅ **Advanced Reporting**: Generate HTML, PDF, Excel, CSV reports
- ✅ **Mobile Responsive**: Works on all devices

## API Endpoints

- `GET /api/health` - Health check
- `POST /api/upload-excel` - Excel file upload (returns demo data)

## File Structure

```
deploy-package/
├── server-ultra-simple.js    # Main application server
├── public/                   # Static files
│   ├── index.html           # Main application
│   └── ...                  # Other static assets
├── package.json             # Dependencies and scripts
├── package-lock.json        # Lock file
└── README.md               # Documentation
```

## System Requirements

- Node.js 16.0.0 or higher
- 512MB RAM minimum
- 100MB disk space

## Troubleshooting

### Port Already in Use
```bash
# Kill existing processes
pkill -f "node.*server-ultra-simple"

# Or use different port
PORT=3001 npm start
```

### Permission Issues
```bash
# Make script executable
chmod +x server-ultra-simple.js
```

### Health Check
```bash
# Check if server is running
curl http://localhost:3000/api/health
```

## Support

For issues and questions, please refer to the main documentation or contact support.

---

**Deployment Status**: ✅ READY
**Last Updated**: 2025-08-10T09:23:57.089Z
