#!/bin/bash

# Daily Handover System Start Script
echo "🚀 Starting Daily Handover System..."

# Set default port if not specified
PORT=${PORT:-3000}

# Start the server
echo "🌐 Server will be available at http://localhost:$PORT"
echo "📊 Health check: http://localhost:$PORT/api/health"
echo "⚡ Starting server..."

node server-ultra-simple.js
