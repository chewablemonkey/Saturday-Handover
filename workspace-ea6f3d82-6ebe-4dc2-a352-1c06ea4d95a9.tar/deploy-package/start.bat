@echo off
REM Daily Handover System Start Script
echo 🚀 Starting Daily Handover System...

REM Set default port if not specified
if "%PORT%"=="" set PORT=3000

REM Start the server
echo 🌐 Server will be available at http://localhost:%PORT%
echo 📊 Health check: http://localhost:%PORT%/api/health
echo ⚡ Starting server...

node server-ultra-simple.js
