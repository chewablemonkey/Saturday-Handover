#!/bin/bash

# Daily Handover System Installation Script
echo "🚀 Installing Daily Handover System..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16.0.0 or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'.' -f1 | cut -d'v' -f2)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js version 16.0.0 or higher is required. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create uploads directory
mkdir -p uploads

# Set permissions
chmod +x start.sh
chmod +x server-ultra-simple.js

echo "✅ Installation completed!"
echo ""
echo "🚀 To start the application:"
echo "   ./start.sh"
echo ""
echo "🌐 Or use systemd service (Linux):"
echo "   sudo cp daily-handover.service /etc/systemd/system/"
echo "   sudo systemctl daemon-reload"
echo "   sudo systemctl enable daily-handover"
echo "   sudo systemctl start daily-handover"
echo ""
echo "📊 Health check: http://localhost:3000/api/health"
