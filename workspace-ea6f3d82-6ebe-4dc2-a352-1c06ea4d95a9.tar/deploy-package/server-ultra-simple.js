#!/usr/bin/env node

// Ultra-simple server for Daily Handover System
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const querystring = require('querystring');

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// MIME types
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
};

// Create HTTP server
const server = http.createServer((req, res) => {
  // Parse URL
  const parsedUrl = url.parse(req.url);
  let pathname = parsedUrl.pathname;
  
  // Health check endpoint
  if (pathname === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ message: "Good!" }));
    return;
  }
  
  // Handle file uploads (simplified - in production, use proper multipart parsing)
  if (pathname === '/api/upload-excel' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      // For demo purposes, return mock data
      // In production, you'd parse multipart form data here
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        totalDrivers: 5,
        totalConsignments: 25,
        topDrivers: [
          { name: 'John Doe', consignments: 8 },
          { name: 'Jane Smith', consignments: 7 },
          { name: 'Bob Johnson', consignments: 6 },
          { name: 'Alice Brown', consignments: 3 },
          { name: 'Charlie Wilson', consignments: 1 }
        ],
        bottomDrivers: [
          { name: 'Charlie Wilson', consignments: 1 },
          { name: 'Alice Brown', consignments: 3 },
          { name: 'Bob Johnson', consignments: 6 },
          { name: 'Jane Smith', consignments: 7 },
          { name: 'John Doe', consignments: 8 }
        ],
        message: 'File analyzed successfully (demo mode)'
      }));
    });
    return;
  }
  
  // Serve static files
  if (pathname === '/') {
    pathname = '/index.html';
  }
  
  const filePath = path.join(__dirname, 'public', pathname);
  const ext = path.extname(filePath);
  const contentType = mimeTypes[ext] || 'application/octet-stream';
  
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // File not found
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>404 Not Found</h1><p>Page not found</p></body></html>');
      } else {
        // Server error
        res.writeHead(500, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>500 Internal Server Error</h1><p>Server error</p></body></html>');
      }
    } else {
      // Success
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Start server
server.listen(PORT, HOST, () => {
  console.log(`> Daily Handover System running at http://${HOST}:${PORT}`);
  console.log(`> Health check: http://${HOST}:${PORT}/api/health`);
  console.log(`> Demo mode: Excel upload will return mock data`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});