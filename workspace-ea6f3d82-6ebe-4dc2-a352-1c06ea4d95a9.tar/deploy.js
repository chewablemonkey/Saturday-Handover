#!/usr/bin/env node

/**
 * Daily Handover System - Deployment Script
 * This script prepares the application for deployment by creating a production-ready package
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Starting Daily Handover System deployment preparation...');

// Create deployment package directory
const deployDir = path.join(__dirname, 'deploy-package');
if (fs.existsSync(deployDir)) {
  fs.rmSync(deployDir, { recursive: true, force: true });
}
fs.mkdirSync(deployDir, { recursive: true });

// Copy essential files
console.log('📦 Copying essential files...');
const filesToCopy = [
  'server-ultra-simple.js',
  'public',
  'package.json',
  'package-lock.json',
  'README.md',
  'DEPLOYMENT.md'
];

filesToCopy.forEach(file => {
  const source = path.join(__dirname, file);
  const dest = path.join(deployDir, file);
  
  if (fs.existsSync(source)) {
    if (fs.statSync(source).isDirectory()) {
      fs.cpSync(source, dest, { recursive: true });
    } else {
      fs.copyFileSync(source, dest);
    }
    console.log(`✅ Copied: ${file}`);
  } else {
    console.log(`⚠️  Not found: ${file}`);
  }
});

// Create a simplified package.json for deployment
console.log('📝 Creating deployment package.json...');
const packageJson = {
  name: 'daily-handover-system',
  version: '1.0.0',
  description: 'Daily Handover System - Production Deployment',
  main: 'server-ultra-simple.js',
  scripts: {
    start: 'node server-ultra-simple.js',
    'start:dev': 'node server-ultra-simple.js'
  },
  engines: {
    node: '>=16.0.0'
  },
  author: 'Daily Handover System',
  license: 'MIT'
};

fs.writeFileSync(
  path.join(deployDir, 'package.json'),
  JSON.stringify(packageJson, null, 2)
);

// Create deployment instructions
console.log('📋 Creating deployment instructions...');
const instructions = `# Daily Handover System - Deployment Instructions

## Quick Start

### Option 1: Direct Node.js (Recommended)
\`\`\`bash
# Install dependencies
npm install

# Start the application
npm start

# The application will be available at http://localhost:3000
\`\`\`

### Option 2: With Custom Port
\`\`\`bash
# Start on port 3001
PORT=3001 npm start
\`\`\`

### Option 3: Docker Deployment
\`\`\`bash
# Build Docker image
docker build -t daily-handover .

# Run container
docker run -p 3000:3000 daily-handover
\`\`\`

## Features

- ✅ **Staff Management**: Track office and warehouse staff
- ✅ **Driver Performance**: Monitor top/bottom performers by volume
- ✅ **Excel Integration**: Upload and analyze spreadsheets (demo mode)
- ✅ **Real-time Summary**: Total drivers and shipments on road
- ✅ **Issue Tracking**: Document sorting issues and route allocations
- ✅ **Advanced Reporting**: Generate HTML, PDF, Excel, CSV reports
- ✅ **Mobile Responsive**: Works on all devices

## API Endpoints

- \`GET /api/health\` - Health check
- \`POST /api/upload-excel\` - Excel file upload (returns demo data)

## File Structure

\`\`\`
deploy-package/
├── server-ultra-simple.js    # Main application server
├── public/                   # Static files
│   ├── index.html           # Main application
│   └── ...                  # Other static assets
├── package.json             # Dependencies and scripts
├── package-lock.json        # Lock file
└── README.md               # Documentation
\`\`\`

## System Requirements

- Node.js 16.0.0 or higher
- 512MB RAM minimum
- 100MB disk space

## Troubleshooting

### Port Already in Use
\`\`\`bash
# Kill existing processes
pkill -f "node.*server-ultra-simple"

# Or use different port
PORT=3001 npm start
\`\`\`

### Permission Issues
\`\`\`bash
# Make script executable
chmod +x server-ultra-simple.js
\`\`\`

### Health Check
\`\`\`bash
# Check if server is running
curl http://localhost:3000/api/health
\`\`\`

## Support

For issues and questions, please refer to the main documentation or contact support.

---

**Deployment Status**: ✅ READY
**Last Updated**: ${new Date().toISOString()}
`;

fs.writeFileSync(path.join(deployDir, 'DEPLOY_INSTRUCTIONS.md'), instructions);

// Create a simple start script for different environments
console.log('🔧 Creating start scripts...');

// Linux/Mac start script
const linuxStartScript = `#!/bin/bash

# Daily Handover System Start Script
echo "🚀 Starting Daily Handover System..."

# Set default port if not specified
PORT=\${PORT:-3000}

# Start the server
echo "🌐 Server will be available at http://localhost:\$PORT"
echo "📊 Health check: http://localhost:\$PORT/api/health"
echo "⚡ Starting server..."

node server-ultra-simple.js
`;

fs.writeFileSync(path.join(deployDir, 'start.sh'), linuxStartScript);
fs.chmodSync(path.join(deployDir, 'start.sh'), '755');

// Windows start script
const windowsStartScript = `@echo off
REM Daily Handover System Start Script
echo 🚀 Starting Daily Handover System...

REM Set default port if not specified
if "%PORT%"=="" set PORT=3000

REM Start the server
echo 🌐 Server will be available at http://localhost:%PORT%
echo 📊 Health check: http://localhost:%PORT%/api/health
echo ⚡ Starting server...

node server-ultra-simple.js
`;

fs.writeFileSync(path.join(deployDir, 'start.bat'), windowsStartScript);

// Create a systemd service file for Linux
console.log('⚙️  Creating systemd service file...');
const systemdService = `[Unit]
Description=Daily Handover System
After=network.target

[Service]
Type=simple
User=nodejs
WorkingDirectory=/opt/daily-handover
ExecStart=/usr/bin/node server-ultra-simple.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOST=0.0.0.0

[Install]
WantedBy=multi-user.target
`;

fs.writeFileSync(path.join(deployDir, 'daily-handover.service'), systemdService);

// Create installation script
console.log('📥 Creating installation script...');
const installScript = `#!/bin/bash

# Daily Handover System Installation Script
echo "🚀 Installing Daily Handover System..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16.0.0 or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=\$(node -v | cut -d'.' -f1 | cut -d'v' -f2)
if [ "\$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js version 16.0.0 or higher is required. Current version: \$(node -v)"
    exit 1
fi

echo "✅ Node.js \$(node -v) detected"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create uploads directory
mkdir -p uploads

# Set permissions
chmod +x start.sh
chmod +x server-ultra-simple.js

echo "✅ Installation completed!"
echo ""
echo "🚀 To start the application:"
echo "   ./start.sh"
echo ""
echo "🌐 Or use systemd service (Linux):"
echo "   sudo cp daily-handover.service /etc/systemd/system/"
echo "   sudo systemctl daemon-reload"
echo "   sudo systemctl enable daily-handover"
echo "   sudo systemctl start daily-handover"
echo ""
echo "📊 Health check: http://localhost:3000/api/health"
`;

fs.writeFileSync(path.join(deployDir, 'install.sh'), installScript);
fs.chmodSync(path.join(deployDir, 'install.sh'), '755');

// Create archive
console.log('📦 Creating deployment archive...');
try {
  execSync('cd deploy-package && tar -czf ../daily-handover-system.tar.gz .', { stdio: 'inherit' });
  console.log('✅ Archive created: daily-handover-system.tar.gz');
} catch (error) {
  console.log('⚠️  Could not create archive (tar not available)');
}

// Create ZIP archive (if zip is available)
try {
  execSync('cd deploy-package && zip -r ../daily-handover-system.zip .', { stdio: 'inherit' });
  console.log('✅ ZIP archive created: daily-handover-system.zip');
} catch (error) {
  console.log('⚠️  Could not create ZIP archive (zip not available)');
}

console.log('');
console.log('🎉 Deployment package created successfully!');
console.log('');
console.log('📁 Deployment package location: ./deploy-package/');
console.log('📦 Archives: ./daily-handover-system.tar.gz (and .zip if available)');
console.log('');
console.log('🚀 Quick deployment commands:');
console.log('   cd deploy-package');
console.log('   npm install');
console.log('   npm start');
console.log('');
console.log('📋 For detailed instructions, see: deploy-package/DEPLOY_INSTRUCTIONS.md');
console.log('⚙️  For automated installation, run: deploy-package/install.sh');
console.log('');
console.log('✅ Deployment preparation completed!');