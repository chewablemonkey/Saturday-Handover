#!/usr/bin/env node

// Simple production server for Daily Handover System
const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const xlsx = require('xlsx');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.includes('excel') || file.mimetype.includes('spreadsheet') || 
        file.originalname.match(/\.(xlsx|xls)$/)) {
      cb(null, true);
    } else {
      cb(new Error('Only Excel files are allowed'), false);
    }
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ message: "Good!" });
});

// Excel upload endpoint
app.post('/api/upload-excel', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    const workbook = xlsx.readFile(req.file.path);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = xlsx.utils.sheet_to_json(worksheet);

    // Process the data (simplified version)
    const drivers = [];
    const driverNameColumns = ['driver', 'driver name', 'name', 'employee'];
    const consignmentColumns = ['consignments', 'deliveries', 'orders', 'volume'];

    const firstRow = jsonData[0] || {};
    const actualColumns = Object.keys(firstRow);
    
    let driverColumn = actualColumns.find(col => 
      driverNameColumns.some(name => col.toLowerCase().includes(name))
    ) || actualColumns[0];
    
    let consignmentColumn = actualColumns.find(col => 
      consignmentColumns.some(name => col.toLowerCase().includes(name))
    ) || actualColumns[1];

    // Extract driver data
    for (const row of jsonData) {
      const driverName = row[driverColumn];
      const consignments = parseInt(row[consignmentColumn]) || 0;

      if (driverName && consignments >= 0) {
        drivers.push({
          name: String(driverName).trim(),
          consignments
        });
      }
    }

    if (drivers.length === 0) {
      return res.status(400).json({ error: 'No valid driver data found' });
    }

    const totalDrivers = drivers.length;
    const totalConsignments = drivers.reduce((sum, driver) => sum + driver.consignments, 0);
    const sortedDrivers = [...drivers].sort((a, b) => b.consignments - a.consignments);
    const topDrivers = sortedDrivers.slice(0, 5);
    const bottomDrivers = [...sortedDrivers].reverse().slice(0, 5);

    // Clean up uploaded file
    fs.unlinkSync(req.file.path);

    res.json({
      totalDrivers,
      totalConsignments,
      topDrivers,
      bottomDrivers,
      message: 'File analyzed successfully'
    });

  } catch (error) {
    console.error('Error processing Excel file:', error);
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({ error: 'Failed to process Excel file' });
  }
});

// Serve the main application
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Start server
app.listen(PORT, HOST, () => {
  console.log(`> Daily Handover System running at http://${HOST}:${PORT}`);
  console.log(`> Health check: http://${HOST}:${PORT}/api/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});