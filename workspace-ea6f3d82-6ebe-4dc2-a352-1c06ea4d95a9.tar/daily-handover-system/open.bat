@echo off
REM Daily Handover System - Open Directly
echo 🚀 Opening Daily Handover System...

REM Try to open with default browser
start index.html

echo ✅ System should open in your default browser
echo 💡 If it doesn't open, double-click index.html manually
echo 📱 Works on all devices - mobile, tablet, and desktop!
