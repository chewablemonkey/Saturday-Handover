#!/bin/bash

# Daily Handover System - Quick Start Script
echo "🚀 Starting Daily Handover System..."

# Set default port if not specified
PORT=${PORT:-3000}

# Start the server
echo "🌐 Local: http://localhost:$PORT"
echo "🌐 Network: http://$(hostname -I | awk '{print $1}'):$PORT"
echo "📊 Health Check: http://localhost:$PORT/api/health"
echo "💡 Open the URL in your browser to start using the system!"
echo ""
echo "⚡ Starting server..."

node server.js
