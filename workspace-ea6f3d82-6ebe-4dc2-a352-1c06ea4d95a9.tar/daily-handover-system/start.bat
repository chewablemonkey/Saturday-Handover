@echo off
REM Daily Handover System - Quick Start Script
echo 🚀 Starting Daily Handover System...

REM Set default port if not specified
if "%PORT%"=="" set PORT=3000

REM Start the server
echo 🌐 Local: http://localhost:%PORT%
echo 📊 Health Check: http://localhost:%PORT%/api/health
echo 💡 Open the URL in your browser to start using the system!
echo.
echo ⚡ Starting server...

node server.js
