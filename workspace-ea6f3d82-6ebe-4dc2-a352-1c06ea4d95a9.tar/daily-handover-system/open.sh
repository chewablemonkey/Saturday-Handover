#!/bin/bash

# Daily Handover System - Open Directly
echo "🚀 Opening Daily Handover System..."

# Try to open with default browser
if command -v xdg-open &> /dev/null; then
    xdg-open index.html
elif command -v open &> /dev/null; then
    open index.html
else
    echo "💡 Please open index.html in your web browser"
fi

echo "✅ System should open in your default browser"
echo "💡 If it doesn't open, double-click index.html manually"
echo "📱 Works on all devices - mobile, tablet, and desktop!"
