#!/usr/bin/env node

/**
 * Create Static Deployment Package
 * This script creates a complete static HTML deployment that doesn't require Next.js build
 */

const fs = require('fs');
const path = require('path');

console.log('🚀 Creating static deployment package...');

// Create static deployment directory
const staticDir = path.join(__dirname, 'static-deployment');
if (fs.existsSync(staticDir)) {
  fs.rmSync(staticDir, { recursive: true, force: true });
}
fs.mkdirSync(staticDir, { recursive: true });

// Create a complete static HTML application
const staticHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Handover System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <style>
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .template-card { 
            cursor: pointer; 
            transition: all 0.2s ease;
        }
        .template-card:hover { transform: translateY(-2px); }
        .template-card.selected { 
            border: 2px solid #3b82f6; 
            background-color: #eff6ff; 
        }
        .report-preview {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            padding: 1rem;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto p-4 max-w-6xl">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-center mb-2">Daily Handover System</h1>
            <p class="text-center text-gray-600">Track staff, drivers, and daily operations</p>
        </div>

        <!-- Summary Cards -->
        <div class="grid md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-sm border p-6">
                <h3 class="text-lg font-semibold mb-2 flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283-.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                    Total Drivers on Road
                </h3>
                <input type="number" id="totalDriversOnRoad" placeholder="Enter total drivers" 
                       class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>

            <div class="bg-white rounded-lg shadow-sm border p-6">
                <h3 class="text-lg font-semibold mb-2 flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    Total Shipments on Road
                </h3>
                <input type="number" id="totalShipmentsOnRoad" placeholder="Enter total shipments" 
                       class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
        </div>

        <!-- Tabs -->
        <div class="bg-white rounded-lg shadow-sm border mb-8">
            <div class="border-b">
                <nav class="flex space-x-8 px-6" aria-label="Tabs">
                    <button onclick="switchTab('manual')" class="tab-button py-4 px-1 border-b-2 border-blue-500 font-medium text-sm text-blue-600" data-tab="manual">
                        Manual Entry
                    </button>
                    <button onclick="switchTab('upload')" class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300" data-tab="upload">
                        Excel Upload
                    </button>
                </nav>
            </div>

            <!-- Manual Entry Tab -->
            <div id="manual" class="tab-content active p-6 space-y-6">
                <!-- Staff Information -->
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283-.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                            Staff in Office
                        </h3>
                        <div class="flex gap-2 mb-4">
                            <input type="text" id="officeStaff" placeholder="Enter staff name" 
                                   class="flex-1 p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   onkeypress="if(event.key==='Enter') addStaff('office')">
                            <button onclick="addStaff('office')" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Add</button>
                        </div>
                        <div id="officeStaffList" class="flex flex-wrap gap-2"></div>
                    </div>

                    <div>
                        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                            </svg>
                            Staff in Warehouse
                        </h3>
                        <div class="flex gap-2 mb-4">
                            <input type="text" id="warehouseStaff" placeholder="Enter staff name" 
                                   class="flex-1 p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   onkeypress="if(event.key==='Enter') addStaff('warehouse')">
                            <button onclick="addStaff('warehouse')" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Add</button>
                        </div>
                        <div id="warehouseStaffList" class="flex flex-wrap gap-2"></div>
                    </div>
                </div>

                <!-- Driver Information -->
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                            </svg>
                            Top 5 Drivers by Volume
                        </h3>
                        <div class="grid grid-cols-2 gap-2 mb-4">
                            <input type="text" id="topDriverName" placeholder="Driver name" 
                                   class="p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <input type="number" id="topDriverConsignments" placeholder="Consignments" 
                                   class="p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                        <button onclick="addDriver('top')" class="w-full px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mb-4">Add Top Driver</button>
                        <div id="topDriversList" class="space-y-2"></div>
                    </div>

                    <div>
                        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path>
                            </svg>
                            Bottom 5 Drivers by Volume
                        </h3>
                        <div class="grid grid-cols-2 gap-2 mb-4">
                            <input type="text" id="bottomDriverName" placeholder="Driver name" 
                                   class="p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <input type="number" id="bottomDriverConsignments" placeholder="Consignments" 
                                   class="p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>
                        <button onclick="addDriver('bottom')" class="w-full px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 mb-4">Add Bottom Driver</button>
                        <div id="bottomDriversList" class="space-y-2"></div>
                    </div>
                </div>

                <!-- Issues and Routes -->
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                            </svg>
                            Issues with Sort
                        </h3>
                        <textarea id="issuesWithSort" placeholder="Describe any issues with the sorting process..." 
                                  class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                                  rows="4"></textarea>
                    </div>

                    <div>
                        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path>
                            </svg>
                            Vacant Route Allocation
                        </h3>
                        <textarea id="vacantRouteAllocation" placeholder="Describe any vacant routes or allocation issues..." 
                                  class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                                  rows="4"></textarea>
                    </div>
                </div>
            </div>

            <!-- Excel Upload Tab -->
            <div id="upload" class="tab-content p-6">
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <svg class="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                    </svg>
                    <label for="file-upload" class="cursor-pointer">
                        <div class="space-y-2">
                            <p class="text-lg font-medium">Upload Excel File</p>
                            <p class="text-sm text-gray-500">
                                Click to browse or drag and drop your Excel file here
                            </p>
                        </div>
                    </label>
                    <input id="file-upload" type="file" accept=".xlsx,.xls" class="hidden" onchange="handleFileUpload(event)">
                </div>

                <div id="uploadLoading" class="text-center mt-4 hidden">
                    <p class="text-sm text-gray-500">Analyzing file...</p>
                </div>

                <div id="uploadResults" class="grid md:grid-cols-2 gap-4 mt-6 hidden">
                    <div class="bg-blue-50 p-6 rounded-lg text-center">
                        <div class="text-3xl font-bold text-blue-600" id="totalDriversResult">0</div>
                        <p class="text-sm text-gray-600">Total Drivers</p>
                    </div>
                    <div class="bg-green-50 p-6 rounded-lg text-center">
                        <div class="text-3xl font-bold text-green-600" id="totalConsignmentsResult">0</div>
                        <p class="text-sm text-gray-600">Total Consignments</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Advanced Reporting Section -->
        <div class="bg-white rounded-lg shadow-sm border p-6">
            <h2 class="text-xl font-semibold mb-6 flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
                Advanced Reporting
            </h2>

            <!-- Template Selection -->
            <div class="mb-6">
                <h3 class="text-lg font-medium mb-4">Select Report Template</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="template-card border rounded-lg p-4 selected" onclick="selectTemplate('standard')" data-template="standard">
                        <h4 class="font-semibold mb-2">Standard Report</h4>
                        <p class="text-sm text-gray-600 mb-3">Complete daily handover report with all sections</p>
                        <div class="flex flex-wrap gap-1">
                            <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">summary</span>
                            <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">staff</span>
                            <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">drivers</span>
                            <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">issues</span>
                            <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">routes</span>
                        </div>
                    </div>

                    <div class="template-card border rounded-lg p-4" onclick="selectTemplate('executive')" data-template="executive">
                        <h4 class="font-semibold mb-2">Executive Summary</h4>
                        <p class="text-sm text-gray-600 mb-3">High-level overview for management</p>
                        <div class="flex flex-wrap gap-1">
                            <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">summary</span>
                            <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">drivers</span>
                        </div>
                    </div>

                    <div class="template-card border rounded-lg p-4" onclick="selectTemplate('operations')" data-template="operations">
                        <h4 class="font-semibold mb-2">Operations Detail</h4>
                        <p class="text-sm text-gray-600 mb-3">Detailed operations and staff information</p>
                        <div class="flex flex-wrap gap-1">
                            <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">summary</span>
                            <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">staff</span>
                            <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">issues</span>
                            <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">routes</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Report Generation -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <button onclick="generateHTMLReport()" class="flex items-center justify-center gap-2 px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    HTML Report
                </button>
                <button onclick="generatePDFReport()" class="flex items-center justify-center gap-2 px-4 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                    </svg>
                    PDF Report
                </button>
                <button onclick="generateExcelReport()" class="flex items-center justify-center gap-2 px-4 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    Excel Report
                </button>
            </div>

            <!-- Report Preview -->
            <div id="reportPreview" class="report-preview hidden">
                <h3 class="text-lg font-medium mb-4">Report Preview</h3>
                <div id="previewContent"></div>
            </div>
        </div>
    </div>

    <script>
        // Global data storage
        let handoverData = {
            staffInOffice: [],
            staffInWarehouse: [],
            topDrivers: [],
            bottomDrivers: [],
            issuesWithSort: '',
            vacantRouteAllocation: '',
            totalDriversOnRoad: 0,
            totalShipmentsOnRoad: 0,
            totalDrivers: 0,
            totalConsignments: 0
        };

        let selectedTemplate = 'standard';

        // Tab switching
        function switchTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active state from all tab buttons
            document.querySelectorAll('.tab-button').forEach(button => {
                button.classList.remove('border-blue-500', 'text-blue-600');
                button.classList.add('border-transparent', 'text-gray-500');
            });
            
            // Show selected tab
            document.getElementById(tabName).classList.add('active');
            
            // Activate selected tab button
            const activeButton = document.querySelector(\`[data-tab="\${tabName}"]\`);
            activeButton.classList.remove('border-transparent', 'text-gray-500');
            activeButton.classList.add('border-blue-500', 'text-blue-600');
        }

        // Staff management
        function addStaff(type) {
            const input = document.getElementById(type + 'Staff');
            const name = input.value.trim();
            
            if (!name) return;
            
            handoverData[\`staffIn\${type.charAt(0).toUpperCase() + type.slice(1)}\`].push(name);
            input.value = '';
            
            renderStaffList(type);
        }

        function removeStaff(type, index) {
            handoverData[\`staffIn\${type.charAt(0).toUpperCase() + type.slice(1)}\`].splice(index, 1);
            renderStaffList(type);
        }

        function renderStaffList(type) {
            const container = document.getElementById(type + 'StaffList');
            const staffList = handoverData[\`staffIn\${type.charAt(0).toUpperCase() + type.slice(1)}\`];
            
            container.innerHTML = staffList.map((staff, index) => 
                \`<span class="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm cursor-pointer hover:bg-gray-200" onclick="removeStaff('\${type}', \${index})">
                    \${staff} ×
                </span>\`
            ).join('');
        }

        // Driver management
        function addDriver(type) {
            const nameInput = document.getElementById(type + 'DriverName');
            const consignmentsInput = document.getElementById(type + 'DriverConsignments');
            
            const name = nameInput.value.trim();
            const consignments = parseInt(consignmentsInput.value);
            
            if (!name || !consignments) return;
            
            handoverData[type + 'Drivers'].push({ name, consignments });
            
            nameInput.value = '';
            consignmentsInput.value = '';
            
            renderDriverList(type);
        }

        function removeDriver(type, index) {
            handoverData[type + 'Drivers'].splice(index, 1);
            renderDriverList(type);
        }

        function renderDriverList(type) {
            const container = document.getElementById(type + 'DriversList');
            const driverList = handoverData[type + 'Drivers'];
            
            container.innerHTML = driverList.map((driver, index) => 
                \`<div class="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <span>\${driver.name}</span>
                    <div class="flex items-center gap-2">
                        <span class="font-semibold">\${driver.consignments}</span>
                        <button onclick="removeDriver('\${type}', \${index})" class="text-red-500 hover:text-red-700">×</button>
                    </div>
                </div>\`
            ).join('');
        }

        // File upload handling
        function handleFileUpload(event) {
            const file = event.target.files[0];
            if (!file) return;
            
            // Show loading
            document.getElementById('uploadLoading').classList.remove('hidden');
            document.getElementById('uploadResults').classList.add('hidden');
            
            // Simulate file processing (in real implementation, this would process the Excel file)
            setTimeout(() => {
                // Mock data for demo
                const mockData = {
                    totalDrivers: 5,
                    totalConsignments: 25,
                    topDrivers: [
                        { name: 'John Doe', consignments: 8 },
                        { name: 'Jane Smith', consignments: 7 },
                        { name: 'Bob Johnson', consignments: 6 },
                        { name: 'Alice Brown', consignments: 3 },
                        { name: 'Charlie Wilson', consignments: 1 }
                    ],
                    bottomDrivers: [
                        { name: 'Charlie Wilson', consignments: 1 },
                        { name: 'Alice Brown', consignments: 3 },
                        { name: 'Bob Johnson', consignments: 6 },
                        { name: 'Jane Smith', consignments: 7 },
                        { name: 'John Doe', consignments: 8 }
                    ]
                };
                
                // Update data
                Object.assign(handoverData, mockData);
                
                // Update UI
                document.getElementById('totalDriversResult').textContent = mockData.totalDrivers;
                document.getElementById('totalConsignmentsResult').textContent = mockData.totalConsignments;
                
                // Update summary fields
                document.getElementById('totalDriversOnRoad').value = mockData.totalDrivers;
                document.getElementById('totalShipmentsOnRoad').value = mockData.totalConsignments;
                handoverData.totalDriversOnRoad = mockData.totalDrivers;
                handoverData.totalShipmentsOnRoad = mockData.totalConsignments;
                
                // Render driver lists
                renderDriverList('top');
                renderDriverList('bottom');
                
                // Hide loading, show results
                document.getElementById('uploadLoading').classList.add('hidden');
                document.getElementById('uploadResults').classList.remove('hidden');
                
                alert('Excel file analyzed successfully!');
            }, 2000);
        }

        // Template selection
        function selectTemplate(templateId) {
            selectedTemplate = templateId;
            
            // Update UI
            document.querySelectorAll('.template-card').forEach(card => {
                card.classList.remove('selected');
            });
            document.querySelector(\`[data-template="\${templateId}"]\`).classList.add('selected');
        }

        // Report generation
        function generateHTMLReport() {
            const html = generateReportHTML(selectedTemplate);
            const blob = new Blob([html], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = \`daily-handover-\${new Date().toISOString().split('T')[0]}.html\`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            alert('HTML report downloaded successfully!');
        }

        function generatePDFReport() {
            const html = generateReportHTML(selectedTemplate);
            
            // Create a temporary div to render HTML
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            tempDiv.style.position = 'absolute';
            tempDiv.style.left = '-9999px';
            tempDiv.style.width = '800px';
            document.body.appendChild(tempDiv);
            
            // Convert to canvas using html2canvas
            html2canvas(tempDiv.querySelector('.container'), {
                scale: 2,
                useCORS: true,
                allowTaint: true
            }).then(canvas => {
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF('p', 'mm', 'a4');
                const imgData = canvas.toDataURL('image/png');
                
                const pdfWidth = pdf.internal.pageSize.getWidth();
                const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                
                pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
                
                // Clean up
                document.body.removeChild(tempDiv);
                
                pdf.save(\`daily-handover-\${new Date().toISOString().split('T')[0]}.pdf\`);
                alert('PDF report downloaded successfully!');
            });
        }

        function generateExcelReport() {
            // Create workbook
            const wb = XLSX.utils.book_new();
            
            // Summary sheet
            const summaryData = [
                ['Metric', 'Value'],
                ['Total Drivers on Road', handoverData.totalDriversOnRoad || 0],
                ['Total Shipments on Road', handoverData.totalShipmentsOnRoad || 0],
                ['Total Drivers', handoverData.totalDrivers || 0],
                ['Total Consignments', handoverData.totalConsignments || 0]
            ];
            const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
            XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');
            
            // Staff sheet
            const staffData = [
                ['Type', 'Name'],
                ...handoverData.staffInOffice.map(name => ['Office', name]),
                ...handoverData.staffInWarehouse.map(name => ['Warehouse', name])
            ];
            const staffWs = XLSX.utils.aoa_to_sheet(staffData);
            XLSX.utils.book_append_sheet(wb, staffWs, 'Staff');
            
            // Drivers sheet
            const driversData = [
                ['Type', 'Name', 'Consignments'],
                ...handoverData.topDrivers.map(driver => ['Top', driver.name, driver.consignments]),
                ...handoverData.bottomDrivers.map(driver => ['Bottom', driver.name, driver.consignments])
            ];
            const driversWs = XLSX.utils.aoa_to_sheet(driversData);
            XLSX.utils.book_append_sheet(wb, driversWs, 'Drivers');
            
            // Issues sheet
            const issuesData = [
                ['Category', 'Description'],
                ['Issues with Sort', handoverData.issuesWithSort || 'None'],
                ['Vacant Route Allocation', handoverData.vacantRouteAllocation || 'None']
            ];
            const issuesWs = XLSX.utils.aoa_to_sheet(issuesData);
            XLSX.utils.book_append_sheet(wb, issuesWs, 'Issues');
            
            // Save file
            XLSX.writeFile(wb, \`daily-handover-\${new Date().toISOString().split('T')[0]}.xlsx\`);
            alert('Excel report downloaded successfully!');
        }

        function generateReportHTML(templateId) {
            const templates = {
                standard: {
                    name: 'Standard Report',
                    sections: ['summary', 'staff', 'drivers', 'issues', 'routes'],
                    primaryColor: '#2563eb',
                    secondaryColor: '#64748b'
                },
                executive: {
                    name: 'Executive Summary',
                    sections: ['summary', 'drivers'],
                    primaryColor: '#059669',
                    secondaryColor: '#64748b'
                },
                operations: {
                    name: 'Operations Detail',
                    sections: ['summary', 'staff', 'issues', 'routes'],
                    primaryColor: '#dc2626',
                    secondaryColor: '#64748b'
                }
            };
            
            const template = templates[templateId];
            const sections = template.sections;
            
            let html = \`
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>\${template.name} - Daily Handover Report</title>
                    <style>
                        body { 
                            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                            margin: 0; 
                            padding: 20px; 
                            line-height: 1.6;
                            background-color: #f8fafc;
                        }
                        .container {
                            max-width: 800px;
                            margin: 0 auto;
                            background: white;
                            border-radius: 12px;
                            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                            overflow: hidden;
                        }
                        .header { 
                            background: linear-gradient(135deg, \${template.primaryColor}, \${template.secondaryColor}); 
                            color: white;
                            padding: 30px;
                            text-align: center;
                        }
                        .header h1 {
                            margin: 0;
                            font-size: 2.5rem;
                            font-weight: 700;
                        }
                        .header .date {
                            font-size: 1rem;
                            opacity: 0.8;
                            margin-top: 8px;
                        }
                        .section { 
                            margin: 0; 
                            padding: 25px 30px;
                            border-bottom: 1px solid #e2e8f0;
                        }
                        .section:last-child {
                            border-bottom: none;
                        }
                        .section h2 { 
                            color: \${template.primaryColor}; 
                            margin-top: 0; 
                            margin-bottom: 20px;
                            font-size: 1.5rem;
                            font-weight: 600;
                            border-bottom: 2px solid \${template.primaryColor};
                            padding-bottom: 8px;
                        }
                        .section h3 {
                            color: #334155;
                            margin-top: 20px;
                            margin-bottom: 10px;
                            font-size: 1.1rem;
                            font-weight: 600;
                        }
                        .staff-list { 
                            display: flex; 
                            flex-wrap: wrap; 
                            gap: 8px; 
                            margin-top: 15px; 
                        }
                        .staff-badge { 
                            background: \${template.primaryColor}20; 
                            color: \${template.primaryColor};
                            padding: 6px 12px; 
                            border-radius: 20px; 
                            font-size: 14px;
                            font-weight: 500;
                            border: 1px solid \${template.primaryColor}40;
                        }
                        .driver-table { 
                            width: 100%; 
                            border-collapse: collapse; 
                            margin-top: 15px;
                        }
                        .driver-table th, .driver-table td { 
                            padding: 12px 15px; 
                            text-align: left; 
                            border-bottom: 1px solid #e2e8f0;
                        }
                        .driver-table th { 
                            background: \${template.primaryColor}10; 
                            color: \${template.primaryColor};
                            font-weight: 600;
                        }
                        .stats { 
                            display: grid; 
                            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                            gap: 20px; 
                            margin-top: 20px; 
                        }
                        .stat-item { 
                            background: \${template.primaryColor}10; 
                            padding: 20px; 
                            border-radius: 12px; 
                            text-align: center;
                        }
                        .stat-value { 
                            font-size: 2.5rem; 
                            font-weight: 700; 
                            color: \${template.primaryColor};
                            margin-bottom: 5px;
                        }
                        .stat-label { 
                            color: #64748b; 
                            font-size: 14px;
                            font-weight: 500;
                            text-transform: uppercase;
                        }
                        .issue-box {
                            background: #fef2f2;
                            border: 1px solid #fecaca;
                            border-radius: 8px;
                            padding: 15px;
                            margin-top: 15px;
                        }
                        .route-box {
                            background: #f0f9ff;
                            border: 1px solid #bae6fd;
                            border-radius: 8px;
                            padding: 15px;
                            margin-top: 15px;
                        }
                        .empty-state {
                            text-align: center;
                            color: #64748b;
                            font-style: italic;
                            padding: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>\${template.name}</h1>
                            <div class="date">Generated on: \${new Date().toLocaleDateString()}</div>
                        </div>
            \`;
            
            // Add sections based on template
            if (sections.includes('summary')) {
                html += \`
                    <div class="section">
                        <h2>Current Road Summary</h2>
                        <div class="stats">
                            <div class="stat-item">
                                <div class="stat-value">\${handoverData.totalDriversOnRoad || 0}</div>
                                <div class="stat-label">Drivers on Road</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value">\${handoverData.totalShipmentsOnRoad || 0}</div>
                                <div class="stat-label">Shipments on Road</div>
                            </div>
                            \${handoverData.totalDrivers ? \`
                            <div class="stat-item">
                                <div class="stat-value">\${handoverData.totalDrivers}</div>
                                <div class="stat-label">Total Drivers</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value">\${handoverData.totalConsignments}</div>
                                <div class="stat-label">Total Consignments</div>
                            </div>
                            \` : ''}
                        </div>
                    </div>
                \`;
            }
            
            if (sections.includes('staff')) {
                html += \`
                    <div class="section">
                        <h2>Staff Information</h2>
                        <h3>Staff in Office</h3>
                        <div class="staff-list">
                            \${handoverData.staffInOffice.length > 0 
                                ? handoverData.staffInOffice.map(staff => \`<span class="staff-badge">\${staff}</span>\`).join('')
                                : '<div class="empty-state">No staff members listed</div>'
                            }
                        </div>
                        <h3>Staff in Warehouse</h3>
                        <div class="staff-list">
                            \${handoverData.staffInWarehouse.length > 0 
                                ? handoverData.staffInWarehouse.map(staff => \`<span class="staff-badge">\${staff}</span>\`).join('')
                                : '<div class="empty-state">No staff members listed</div>'
                            }
                        </div>
                    </div>
                \`;
            }
            
            if (sections.includes('drivers')) {
                html += \`
                    <div class="section">
                        <h2>Driver Performance</h2>
                        <h3>Top 5 Drivers by Volume</h3>
                        \${handoverData.topDrivers.length > 0 ? \`
                            <table class="driver-table">
                                <thead>
                                    <tr>
                                        <th>Driver Name</th>
                                        <th>Consignments</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    \${handoverData.topDrivers.map(driver => \`
                                        <tr>
                                            <td>\${driver.name}</td>
                                            <td><strong>\${driver.consignments}</strong></td>
                                        </tr>
                                    \`).join('')}
                                </tbody>
                            </table>
                        \` : '<div class="empty-state">No driver performance data available</div>'}
                        
                        <h3>Bottom 5 Drivers by Volume</h3>
                        \${handoverData.bottomDrivers.length > 0 ? \`
                            <table class="driver-table">
                                <thead>
                                    <tr>
                                        <th>Driver Name</th>
                                        <th>Consignments</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    \${handoverData.bottomDrivers.map(driver => \`
                                        <tr>
                                            <td>\${driver.name}</td>
                                            <td><strong>\${driver.consignments}</strong></td>
                                        </tr>
                                    \`).join('')}
                                </tbody>
                            </table>
                        \` : '<div class="empty-state">No driver performance data available</div>'}
                    </div>
                \`;
            }
            
            if (sections.includes('issues')) {
                html += \`
                    <div class="section">
                        <h2>Issues with Sort</h2>
                        \${handoverData.issuesWithSort ? \`
                            <div class="issue-box">
                                <h4>Reported Issues</h4>
                                <p>\${handoverData.issuesWithSort}</p>
                            </div>
                        \` : '<div class="empty-state">No issues reported</div>'}
                    </div>
                \`;
            }
            
            if (sections.includes('routes')) {
                html += \`
                    <div class="section">
                        <h2>Vacant Route Allocation</h2>
                        \${handoverData.vacantRouteAllocation ? \`
                            <div class="route-box">
                                <h4>Route Status</h4>
                                <p>\${handoverData.vacantRouteAllocation}</p>
                            </div>
                        \` : '<div class="empty-state">All routes allocated</div>'}
                    </div>
                \`;
            }
            
            html += \`
                    </div>
                </body>
                </html>
            \`;
            
            return html;
        }

        // Initialize event listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Update summary fields when they change
            document.getElementById('totalDriversOnRoad').addEventListener('input', function(e) {
                handoverData.totalDriversOnRoad = parseInt(e.target.value) || 0;
            });
            
            document.getElementById('totalShipmentsOnRoad').addEventListener('input', function(e) {
                handoverData.totalShipmentsOnRoad = parseInt(e.target.value) || 0;
            });
            
            // Update issues and routes when they change
            document.getElementById('issuesWithSort').addEventListener('input', function(e) {
                handoverData.issuesWithSort = e.target.value;
            });
            
            document.getElementById('vacantRouteAllocation').addEventListener('input', function(e) {
                handoverData.vacantRouteAllocation = e.target.value;
            });
        });
    </script>
</body>
</html>`;

// Write the static HTML file
fs.writeFileSync(path.join(staticDir, 'index.html'), staticHTML);

// Create a simple server for the static deployment
const serverJS = `#!/usr/bin/env node

// Static deployment server for Daily Handover System
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// MIME types
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
};

// Create HTTP server
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url);
  let pathname = parsedUrl.pathname;
  
  // Health check endpoint
  if (pathname === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ message: "Good!" }));
    return;
  }
  
  // Serve static files
  if (pathname === '/') {
    pathname = '/index.html';
  }
  
  const filePath = path.join(__dirname, pathname);
  const ext = path.extname(filePath);
  const contentType = mimeTypes[ext] || 'application/octet-stream';
  
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // File not found
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>404 Not Found</h1><p>Page not found</p></body></html>');
      } else {
        // Server error
        res.writeHead(500, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>500 Internal Server Error</h1><p>Server error</p></body></html>');
      }
    } else {
      // Success
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

// Start server
server.listen(PORT, HOST, () => {
  console.log(\`> Daily Handover System running at http://\${HOST}:\${PORT}\`);
  console.log(\`> Health check: http://\${HOST}:\${PORT}/api/health\`);
  console.log(\`> Static HTML deployment - No Next.js build required!\`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});
`;

fs.writeFileSync(path.join(staticDir, 'server.js'), serverJS);

// Create package.json for static deployment
const packageJSON = {
  name: 'daily-handover-system-static',
  version: '1.0.0',
  description: 'Daily Handover System - Static HTML Deployment',
  main: 'server.js',
  scripts: {
    start: 'node server.js',
    'start:dev': 'node server.js'
  },
  engines: {
    node: '>=16.0.0'
  },
  author: 'Daily Handover System',
  license: 'MIT'
};

fs.writeFileSync(path.join(staticDir, 'package.json'), JSON.stringify(packageJSON, null, 2));

// Create README for static deployment
const readme = `# Daily Handover System - Static Deployment

This is a complete static HTML deployment of the Daily Handover System that doesn't require Next.js build process.

## Features

- ✅ **Staff Management**: Track office and warehouse staff
- ✅ **Driver Performance**: Monitor top/bottom performers by volume
- ✅ **Excel Integration**: Upload and analyze spreadsheets (demo mode)
- ✅ **Real-time Summary**: Total drivers and shipments on road
- ✅ **Issue Tracking**: Document sorting issues and route allocations
- ✅ **Advanced Reporting**: Generate HTML, PDF, Excel reports
- ✅ **Mobile Responsive**: Works on all devices
- ✅ **Zero Dependencies**: No build process required

## Quick Start

### Option 1: Direct Node.js
\`\`\`bash
# Install dependencies (none needed for this static version)
npm start

# The application will be available at http://localhost:3000
\`\`\`

### Option 2: With Custom Port
\`\`\`bash
# Start on port 3001
PORT=3001 npm start
\`\`\`

### Option 3: Docker Deployment
\`\`\`bash
# Build Docker image
docker build -t daily-handover-static .

# Run container
docker run -p 3000:3000 daily-handover-static
\`\`\`

## System Requirements

- Node.js 16.0.0 or higher
- 512MB RAM minimum
- 100MB disk space

## API Endpoints

- \`GET /api/health\` - Health check

## File Structure

\`\`\`
static-deployment/
├── index.html          # Main application
├── server.js           # Simple HTTP server
├── package.json        # Dependencies and scripts
└── README.md           # This file
\`\`\`

## Troubleshooting

### Port Already in Use
\`\`\`bash
# Kill existing processes
pkill -f "node.*server"

# Or use different port
PORT=3001 npm start
\`\`\`

### Health Check
\`\`\`bash
# Check if server is running
curl http://localhost:3000/api/health
\`\`\`

## Deployment

This static deployment is ideal for:
- Production environments where build processes are problematic
- Simple hosting platforms that support Node.js
- Quick deployment without complex build steps
- Environments with limited resources

---

**Deployment Status**: ✅ READY
**Last Updated**: ${new Date().toISOString()}
`;

fs.writeFileSync(path.join(staticDir, 'README.md'), readme);

// Create Dockerfile for static deployment
const dockerfile = `# Use Node.js 18 Alpine Linux image
FROM node:18-alpine

# Set working directory
WORKDIR /app

# Copy application files
COPY . .

# Expose port
EXPOSE 3000

# Set environment variables
ENV NODE_ENV=production
ENV PORT=3000
ENV HOST=0.0.0.0

# Start the application
CMD ["npm", "start"]
`;

fs.writeFileSync(path.join(staticDir, 'Dockerfile'), dockerfile);

// Create start scripts
const startSh = `#!/bin/bash

# Daily Handover System Start Script
echo "🚀 Starting Daily Handover System (Static Deployment)..."

# Set default port if not specified
PORT=\${PORT:-3000}

# Start the server
echo "🌐 Server will be available at http://localhost:\$PORT"
echo "📊 Health check: http://localhost:\$PORT/api/health"
echo "⚡ Starting server..."

node server.js
`;

fs.writeFileSync(path.join(staticDir, 'start.sh'), startSh);
fs.chmodSync(path.join(staticDir, 'start.sh'), '755');

const startBat = `@echo off
REM Daily Handover System Start Script
echo 🚀 Starting Daily Handover System (Static Deployment)...

REM Set default port if not specified
if "%PORT%"=="" set PORT=3000

REM Start the server
echo 🌐 Server will be available at http://localhost:%PORT%
echo 📊 Health check: http://localhost:%PORT%/api/health
echo ⚡ Starting server...

node server.js
`;

fs.writeFileSync(path.join(staticDir, 'start.bat'), startBat);

console.log('');
console.log('🎉 Static deployment package created successfully!');
console.log('');
console.log('📁 Static deployment location: ./static-deployment/');
console.log('');
console.log('🚀 Quick deployment commands:');
console.log('   cd static-deployment');
console.log('   npm start');
console.log('');
console.log('🌐 Or use the start scripts:');
console.log('   ./start.sh (Linux/Mac)');
console.log('   start.bat (Windows)');
console.log('');
console.log('✅ Static deployment completed - No Next.js build required!');