# Daily Handover System - Static Deployment

This is a complete static HTML deployment of the Daily Handover System that doesn't require Next.js build process.

## Features

- ✅ **Staff Management**: Track office and warehouse staff
- ✅ **Driver Performance**: Monitor top/bottom performers by volume
- ✅ **Excel Integration**: Upload and analyze spreadsheets (demo mode)
- ✅ **Real-time Summary**: Total drivers and shipments on road
- ✅ **Issue Tracking**: Document sorting issues and route allocations
- ✅ **Advanced Reporting**: Generate HTML, PDF, Excel reports
- ✅ **Mobile Responsive**: Works on all devices
- ✅ **Zero Dependencies**: No build process required

## Quick Start

### Option 1: Direct Node.js
```bash
# Install dependencies (none needed for this static version)
npm start

# The application will be available at http://localhost:3000
```

### Option 2: With Custom Port
```bash
# Start on port 3001
PORT=3001 npm start
```

### Option 3: Docker Deployment
```bash
# Build Docker image
docker build -t daily-handover-static .

# Run container
docker run -p 3000:3000 daily-handover-static
```

## System Requirements

- Node.js 16.0.0 or higher
- 512MB RAM minimum
- 100MB disk space

## API Endpoints

- `GET /api/health` - Health check

## File Structure

```
static-deployment/
├── index.html          # Main application
├── server.js           # Simple HTTP server
├── package.json        # Dependencies and scripts
└── README.md           # This file
```

## Troubleshooting

### Port Already in Use
```bash
# Kill existing processes
pkill -f "node.*server"

# Or use different port
PORT=3001 npm start
```

### Health Check
```bash
# Check if server is running
curl http://localhost:3000/api/health
```

## Deployment

This static deployment is ideal for:
- Production environments where build processes are problematic
- Simple hosting platforms that support Node.js
- Quick deployment without complex build steps
- Environments with limited resources

---

**Deployment Status**: ✅ READY
**Last Updated**: 2025-08-10T09:40:13.134Z
